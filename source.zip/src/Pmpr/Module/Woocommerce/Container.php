<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5bf0348c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
