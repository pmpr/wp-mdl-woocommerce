<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7a1c41c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Test extends Common { }
