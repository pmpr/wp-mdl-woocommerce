<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8edabe93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Test extends Common { }
