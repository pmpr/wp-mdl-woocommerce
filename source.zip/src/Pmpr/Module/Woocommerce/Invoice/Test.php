<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5712a9080             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Test extends Common { }
