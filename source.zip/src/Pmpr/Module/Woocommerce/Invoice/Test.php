<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b76c1ee4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Test extends Common { }
