<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426bc970d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Test extends Common { }
