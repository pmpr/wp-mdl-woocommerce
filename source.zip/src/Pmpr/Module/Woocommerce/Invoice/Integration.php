<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5712a9080             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\146\x6f\x72\x65\137\151\x6e\166\157\151\143\x65\x5f\x63\x6f\156\x74\145\156\x74", [$this, "\x61\x6f\x67\161\141\167\x65\x61\147\161\x67\x63\x69\x77\141\x6f"])->qcsmikeggeemccuu("\x61\x66\164\145\162\137\x69\x6e\166\157\x69\x63\x65\137\x63\157\x6e\x74\x65\x6e\164", [$this, "\x67\161\x77\x73\155\167\151\x77\x61\163\171\155\x6b\x63\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto ayyweymyuuiauamo; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\160\155\x6c\x5f\x6c\141\x6e\x67\x75\x61\147\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto yqykqysmiquwoasu; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); yqykqysmiquwoasu: ayyweymyuuiauamo: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto mosqsmqimqgqoase; } $sitepress->switch_lang($sitepress->get_default_language()); mosqsmqimqgqoase: } }
