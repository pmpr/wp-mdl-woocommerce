<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11f075210             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\146\x6f\x72\x65\137\x69\156\x76\x6f\151\x63\145\x5f\143\157\x6e\164\x65\156\164", [$this, "\x61\x6f\x67\x71\x61\x77\145\141\147\161\x67\143\151\x77\141\157"])->qcsmikeggeemccuu("\141\x66\x74\x65\x72\x5f\151\x6e\x76\157\x69\143\145\137\143\x6f\156\164\145\156\164", [$this, "\147\161\x77\163\155\x77\151\x77\141\x73\171\x6d\x6b\x63\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto cmqucgoewuyieoyk; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\x6d\x6c\137\x6c\141\x6e\147\165\141\147\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto gimmuoqwckiseaik; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); gimmuoqwckiseaik: cmqucgoewuyieoyk: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto yqykqysmiquwoasu; } $sitepress->switch_lang($sitepress->get_default_language()); yqykqysmiquwoasu: } }
