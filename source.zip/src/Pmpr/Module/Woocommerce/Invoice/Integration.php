<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668c5b76c1ee4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\145\146\x6f\x72\x65\x5f\151\x6e\166\157\151\143\145\x5f\x63\157\x6e\x74\x65\x6e\x74", [$this, "\x61\157\x67\161\141\167\145\x61\x67\x71\147\x63\x69\x77\141\157"])->qcsmikeggeemccuu("\x61\x66\x74\x65\x72\x5f\x69\156\166\x6f\151\143\145\137\x63\157\156\164\145\x6e\164", [$this, "\147\161\167\x73\x6d\167\x69\167\x61\x73\171\x6d\x6b\143\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto egasokooagakisiy; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\x6c\137\x6c\x61\x6e\147\165\x61\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto mswsoaimesegiiic; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); mswsoaimesegiiic: egasokooagakisiy: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto kecwuwwcwokuksyq; } $sitepress->switch_lang($sitepress->get_default_language()); kecwuwwcwokuksyq: } }
