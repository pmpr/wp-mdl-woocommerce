<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e426bc970d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\x66\157\x72\145\137\x69\156\x76\x6f\151\143\x65\137\143\157\x6e\x74\145\156\x74", [$this, "\x61\x6f\147\161\141\167\145\x61\x67\x71\x67\x63\x69\167\141\157"])->qcsmikeggeemccuu("\x61\146\x74\145\162\x5f\151\156\166\157\151\x63\x65\x5f\x63\x6f\156\164\145\156\164", [$this, "\x67\161\x77\x73\155\167\151\x77\x61\x73\x79\155\153\143\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto oocuemosmeeekgas; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\160\x6d\154\137\154\x61\156\x67\x75\x61\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto syuaummumssgwwee; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); syuaummumssgwwee: oocuemosmeeekgas: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto qkcsykuocwuyaice; } $sitepress->switch_lang($sitepress->get_default_language()); qkcsykuocwuyaice: } }
