<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd1873e4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\145\146\x6f\x72\145\137\x69\156\166\x6f\151\143\x65\137\x63\x6f\156\x74\145\156\164", [$this, "\x61\157\x67\161\141\x77\x65\x61\147\161\x67\143\x69\x77\141\157"])->qcsmikeggeemccuu("\141\x66\x74\145\x72\137\x69\x6e\x76\x6f\x69\143\x65\137\x63\x6f\x6e\164\145\156\x74", [$this, "\x67\x71\167\x73\155\x77\151\167\141\x73\x79\155\x6b\x63\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto esaqcqqwuussiiwo; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\160\x6d\154\137\154\141\156\147\165\141\x67\145", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qiiigwkqeoewsuwm; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qiiigwkqeoewsuwm: esaqcqqwuussiiwo: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto ikqeeaysmqgcgawq; } $sitepress->switch_lang($sitepress->get_default_language()); ikqeeaysmqgcgawq: } }
