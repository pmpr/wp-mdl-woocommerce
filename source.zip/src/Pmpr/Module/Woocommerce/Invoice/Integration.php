<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b3b39a2ad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\146\157\x72\x65\137\151\x6e\166\157\151\x63\x65\x5f\143\157\x6e\164\145\156\164", [$this, "\x61\157\147\161\x61\x77\x65\x61\x67\161\x67\x63\x69\x77\141\x6f"])->qcsmikeggeemccuu("\x61\146\x74\x65\162\137\151\x6e\x76\157\151\x63\x65\x5f\x63\x6f\x6e\x74\145\x6e\x74", [$this, "\147\161\x77\x73\155\x77\x69\167\141\163\x79\155\153\x63\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto qgeugwymkkiacwoc; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\x6d\154\137\154\x61\156\x67\165\141\147\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto mqicocmqegwukkwg; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); mqicocmqegwukkwg: qgeugwymkkiacwoc: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto emmsycooskoqmgeg; } $sitepress->switch_lang($sitepress->get_default_language()); emmsycooskoqmgeg: } }
