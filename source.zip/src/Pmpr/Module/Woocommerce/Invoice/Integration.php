<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8edabe93             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\146\x6f\162\x65\137\x69\156\166\x6f\151\143\145\x5f\143\157\156\164\145\x6e\164", [$this, "\141\157\147\161\141\167\x65\141\147\161\x67\x63\151\x77\141\157"])->qcsmikeggeemccuu("\141\x66\164\145\162\x5f\151\x6e\166\x6f\x69\x63\145\x5f\x63\x6f\x6e\x74\145\156\164", [$this, "\147\x71\x77\x73\x6d\167\x69\167\141\163\x79\155\x6b\143\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto sioekkmekwygemyc; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\154\137\x6c\x61\156\x67\165\141\147\145", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto qukocuwgakemmyga; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); qukocuwgakemmyga: sioekkmekwygemyc: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto yiowgigkkwsoqcci; } $sitepress->switch_lang($sitepress->get_default_language()); yiowgigkkwsoqcci: } }
