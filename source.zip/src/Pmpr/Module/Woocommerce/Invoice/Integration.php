<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660dc276d8bdf             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\145\146\x6f\x72\145\x5f\151\x6e\166\x6f\151\x63\x65\137\143\157\x6e\x74\145\156\x74", [$this, "\x61\x6f\x67\161\x61\167\x65\141\147\161\x67\x63\151\167\141\157"])->qcsmikeggeemccuu("\x61\146\164\x65\x72\137\151\156\166\x6f\x69\143\x65\137\143\x6f\156\164\145\156\x74", [$this, "\147\x71\167\x73\155\x77\151\167\141\x73\x79\x6d\153\143\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto qgeugwymkkiacwoc; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\x70\155\154\x5f\154\x61\156\147\x75\141\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto mqicocmqegwukkwg; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); mqicocmqegwukkwg: qgeugwymkkiacwoc: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto emmsycooskoqmgeg; } $sitepress->switch_lang($sitepress->get_default_language()); emmsycooskoqmgeg: } }
