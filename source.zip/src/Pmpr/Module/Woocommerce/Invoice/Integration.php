<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870865dbc43             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\146\157\x72\145\x5f\x69\x6e\x76\157\151\x63\x65\x5f\x63\x6f\156\x74\x65\156\x74", [$this, "\x61\x6f\x67\x71\141\167\x65\141\x67\161\x67\143\x69\x77\x61\157"])->qcsmikeggeemccuu("\x61\x66\x74\145\162\x5f\x69\156\166\x6f\151\x63\x65\137\143\157\156\x74\145\x6e\x74", [$this, "\x67\x71\x77\163\155\167\151\167\141\163\x79\x6d\153\x63\163\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto egasokooagakisiy; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\x77\160\x6d\154\137\x6c\141\x6e\147\x75\141\147\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto mswsoaimesegiiic; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); mswsoaimesegiiic: egasokooagakisiy: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto kecwuwwcwokuksyq; } $sitepress->switch_lang($sitepress->get_default_language()); kecwuwwcwokuksyq: } }
