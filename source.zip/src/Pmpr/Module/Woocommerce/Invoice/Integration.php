<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ca27b14             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\145\146\x6f\x72\x65\137\x69\x6e\x76\157\x69\143\x65\x5f\143\157\156\164\x65\x6e\x74", [$this, "\x61\157\x67\x71\x61\x77\x65\141\x67\161\147\143\151\x77\141\x6f"])->qcsmikeggeemccuu("\141\x66\x74\x65\162\x5f\x69\x6e\x76\157\x69\x63\x65\137\x63\157\156\x74\145\156\164", [$this, "\147\161\x77\163\155\x77\x69\167\141\x73\x79\x6d\x6b\x63\x73\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto gsygwgsiawgmqiyi; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\x70\155\154\137\x6c\x61\156\x67\x75\x61\x67\145", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto wwukgaquuyoissgy; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); wwukgaquuyoissgy: gsygwgsiawgmqiyi: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto qsgqwyqaqiowkmco; } $sitepress->switch_lang($sitepress->get_default_language()); qsgqwyqaqiowkmco: } }
