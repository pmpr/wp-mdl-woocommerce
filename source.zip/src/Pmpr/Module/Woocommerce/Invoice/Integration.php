<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66840138d6ef4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\142\x65\x66\x6f\x72\x65\137\x69\156\166\157\x69\143\145\x5f\x63\157\x6e\164\145\156\x74", [$this, "\141\157\147\x71\x61\167\x65\x61\x67\161\147\x63\x69\x77\x61\157"])->qcsmikeggeemccuu("\x61\146\164\x65\162\137\151\156\166\157\x69\x63\x65\x5f\143\x6f\x6e\x74\145\x6e\164", [$this, "\147\x71\167\163\155\167\151\167\x61\x73\171\155\153\143\163\x69"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto egasokooagakisiy; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\160\155\154\x5f\x6c\141\x6e\147\x75\141\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto mswsoaimesegiiic; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); mswsoaimesegiiic: egasokooagakisiy: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto kecwuwwcwokuksyq; } $sitepress->switch_lang($sitepress->get_default_language()); kecwuwwcwokuksyq: } }
