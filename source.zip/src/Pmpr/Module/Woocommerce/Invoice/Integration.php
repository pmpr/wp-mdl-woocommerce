<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662cf7a1c41c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce\Invoice; class Integration extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x62\x65\x66\x6f\162\x65\x5f\151\x6e\x76\x6f\x69\143\145\x5f\x63\157\156\164\145\x6e\x74", [$this, "\x61\x6f\147\x71\x61\167\x65\141\x67\161\147\143\x69\167\141\157"])->qcsmikeggeemccuu("\x61\x66\164\x65\x72\x5f\151\x6e\166\157\151\143\145\137\143\157\x6e\164\x65\156\164", [$this, "\147\161\x77\163\155\167\x69\x77\141\163\171\155\153\x63\x73\151"]); } public function aogqaweagqgciwao($umwqusowiqmyseom) { global $sitepress; if (!$sitepress) { goto oocuemosmeeekgas; } $swaukaagekiououo = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->igawqaomowicuayw("\167\160\x6d\x6c\x5f\154\141\156\147\165\141\x67\x65", $umwqusowiqmyseom); if (!($swaukaagekiououo != '')) { goto syuaummumssgwwee; } $sitepress->get_current_language(); $sitepress->switch_lang($swaukaagekiououo); syuaummumssgwwee: oocuemosmeeekgas: } public function gqwsmwiwasymkcsi() { global $sitepress; if (!$sitepress) { goto qkcsykuocwuyaice; } $sitepress->switch_lang($sitepress->get_default_language()); qkcsykuocwuyaice: } }
