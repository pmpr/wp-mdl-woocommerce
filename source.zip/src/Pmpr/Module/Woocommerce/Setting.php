<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b85b5581             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\x76\x61\162\x69\141\x62\x6c\x65\x5f\x70\162\157\144\165\x63\x74\137\x67\x75\x69\x64\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\163\150\157\160\137\164\x61\x62\x6c\145\137\x76\x69\x65\x77\137\143\157\154\165\x6d\x6e\x73"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\126\141\x72\x69\x61\x74\151\x6f\156\40\x50\x72\157\x64\x75\x63\164\40\107\165\x69\x64\145", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
