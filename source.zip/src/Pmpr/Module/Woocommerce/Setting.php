<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5bf0348c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Woocommerce; use Pmpr\Common\Cover\Woocommerce\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { const qqiuqmkwamakmmky = self::soqkucakwksaeyce . "\x76\141\x72\151\x61\x62\154\145\137\x70\162\157\x64\x75\x63\x74\x5f\x67\165\151\x64\x65"; const kqaecmeyeicscaye = self::soqkucakwksaeyce . "\x73\150\157\160\x5f\164\141\142\154\x65\x5f\x76\x69\x65\x77\137\143\x6f\x6c\165\155\x6e\163"; public function qssqicawwgqqscui($ikgwqyuyckaewsow = []) { return $this->oaeygwkmgmgksqke([self::qqiuqmkwamakmmky => [Constants::qescuiwgsyuikume => __("\x56\x61\x72\151\141\x74\x69\157\156\40\120\162\157\x64\165\143\164\x20\107\165\151\144\145", PR__MDL__WOOCOMMERCE)]], $ikgwqyuyckaewsow, self::imgaumeywmqsacas); } public static function ckgyyysykiycqwwm() { return self::iwgqamekocwaigci()->wikusamwomuogoau()->giiuwsmyumqwwiyq(self::qqiuqmkwamakmmky, ''); } }
